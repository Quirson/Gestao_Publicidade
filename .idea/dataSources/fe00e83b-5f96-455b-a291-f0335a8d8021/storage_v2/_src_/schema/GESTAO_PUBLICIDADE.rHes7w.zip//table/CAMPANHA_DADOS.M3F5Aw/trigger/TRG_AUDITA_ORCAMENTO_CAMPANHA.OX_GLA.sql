create trigger TRG_AUDITA_ORCAMENTO_CAMPANHA
    after update of ORC_ALOCADO
    on CAMPANHA_DADOS
    for each row
    when (NEW.Orc_alocado <> OLD.Orc_alocado)
DECLARE
    v_user VARCHAR2(100);
BEGIN
    -- Obtém o usuário da base de dados
    SELECT USER INTO v_user FROM DUAL;

    INSERT INTO Log_Auditoria_Orcamento (
        Id_log,
        Cod_camp,
        Data_alteracao,
        User_alterou,
        Valor_antigo,
        Valor_novo
    )
    VALUES (
        seq_log_auditoria.NEXTVAL,
        :OLD.Cod_camp,
        SYSDATE,
        v_user,
        :OLD.Orc_alocado,
        :NEW.Orc_alocado
    );
END;
/

