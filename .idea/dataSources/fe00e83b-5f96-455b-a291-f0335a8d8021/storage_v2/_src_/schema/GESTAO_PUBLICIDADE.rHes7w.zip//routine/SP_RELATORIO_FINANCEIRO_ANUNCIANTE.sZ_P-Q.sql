create PROCEDURE sp_relatorio_financeiro_anunciante (
    p_nif IN Anunciante_Dados.Num_id_fiscal%TYPE,
    p_cursor OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN p_cursor FOR
    SELECT
        c.Cod_camp,
        c.Titulo AS Campanha,
        c.Orc_alocado AS Orcamento,
        fn_calcular_custo_total_campanha(c.Cod_camp) AS Custo_Real,
        (c.Orc_alocado - fn_calcular_custo_total_campanha(c.Cod_camp)) AS Resultado,
        CASE
            WHEN fn_calcular_custo_total_campanha(c.Cod_camp) = 0 THEN 0
            ELSE ROUND(((c.Orc_alocado - fn_calcular_custo_total_campanha(c.Cod_camp)) / c.Orc_alocado) * 100, 2)
        END AS Performance_Perc
    FROM Campanha_Dados c
    WHERE c.Num_id_fiscal = p_nif
    ORDER BY c.Data_inicio DESC;
END sp_relatorio_financeiro_anunciante;
/

