create PROCEDURE sp_inserir_campanha_completa (
    p_num_id_fiscal    IN Campanha_Dados.Num_id_fiscal%TYPE,
    p_titulo          IN Campanha_Dados.Titulo%TYPE,
    p_objectivo       IN Campanha_Dados.Objectivo%TYPE,
    p_pub_alvo        IN Campanha_Dados.Pub_alvo%TYPE,
    p_orc_alocado     IN Campanha_Dados.Orc_alocado%TYPE,
    p_data_inicio     IN VARCHAR2, -- Aceita string para facilitar
    p_data_termino    IN VARCHAR2,
    p_espacos_ids     IN VARCHAR2 DEFAULT NULL,
    p_publico_ids     IN VARCHAR2 DEFAULT NULL,
    p_canais          IN VARCHAR2 DEFAULT NULL
)
IS
    v_cod_camp NUMBER;
    v_limite_cred NUMBER;
    v_orc_total NUMBER := 0;
BEGIN
    -- 1. VERIFICAR LIMITE DE CRÉDITO
    BEGIN
        SELECT Lim_cred_aprov INTO v_limite_cred
        FROM Anunciante_Dados
        WHERE Num_id_fiscal = p_num_id_fiscal;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20001, 'Anunciante não encontrado: ' || p_num_id_fiscal);
    END;

    IF p_orc_alocado > v_limite_cred THEN
        RAISE_APPLICATION_ERROR(-20002, 'Orçamento excede limite de crédito. Limite: ' || v_limite_cred);
    END IF;

    -- 2. GERAR NOVO ID
    SELECT NVL(MAX(Cod_camp), 8000000) + 1 INTO v_cod_camp FROM Campanha_Dados;

    -- 3. INSERIR CAMPANHA
    INSERT INTO Campanha_Dados (
        Cod_camp, Num_id_fiscal, Titulo, Objectivo, Pub_alvo,
        Orc_alocado, Data_inicio, Data_termino
    ) VALUES (
        v_cod_camp,
p_num_id_fiscal, p_titulo, p_objectivo, p_pub_alvo,
        p_orc_alocado, TO_DATE(p_data_inicio, 'DD/MM/YYYY'), TO_DATE(p_data_termino, 'DD/MM/YYYY')
    );

    -- 4. ASSOCIAR ESPAÇOS (se fornecidos)
    IF p_espacos_ids IS NOT NULL THEN
        FOR i IN (SELECT TRIM(REGEXP_SUBSTR(p_espacos_ids, '[^,]+', 1, LEVEL)) AS espaco_id
                  FROM DUAL
                  CONNECT BY REGEXP_SUBSTR(p_espacos_ids, '[^,]+', 1, LEVEL) IS NOT NULL)
        LOOP
            INSERT INTO Campanha_Espaco (Cod_camp, Id_espaco)
            VALUES (v_cod_camp, i.espaco_id);
        END LOOP;
    END IF;
    -- 5. ASSOCIAR PÚBLICO-ALVO (se fornecido)
    IF p_publico_ids IS NOT NULL THEN
        FOR i IN (SELECT TRIM(REGEXP_SUBSTR(p_publico_ids, '[^,]+', 1, LEVEL)) AS publico_id
                  FROM DUAL
                  CONNECT BY REGEXP_SUBSTR(p_publico_ids, '[^,]+', 1, LEVEL) IS NOT NULL)
        LOOP
            INSERT INTO Campanha_PublicoAlvo (Cod_camp, Id_publicoAlvo)
            VALUES (v_cod_camp, i.publico_id);
        END LOOP;
    END IF;

    -- 6. ASSOCIAR CANAIS (se fornecidos)
    IF p_canais IS NOT NULL THEN
        FOR i IN (SELECT TRIM(REGEXP_SUBSTR(p_canais, '[^,]+', 1, LEVEL)) AS canal
                  FROM DUAL
                  CONNECT BY REGEXP_SUBSTR(p_canais, '[^,]+', 1, LEVEL) IS NOT NULL)
        LOOP
            INSERT INTO Campanha_Canal (Cod_camp, Canais_util)
            VALUES (v_cod_camp, i.canal);
        END LOOP;
    END IF;

    COMMIT;

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END sp_inserir_campanha_completa;
/

