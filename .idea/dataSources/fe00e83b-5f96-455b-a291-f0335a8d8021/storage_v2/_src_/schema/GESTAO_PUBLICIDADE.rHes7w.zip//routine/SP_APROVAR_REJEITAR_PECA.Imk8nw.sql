create PROCEDURE sp_aprovar_rejeitar_peca (
    p_id_peca IN Pecas_Criativas.Id_unicoPeca%TYPE,
    p_novo_status IN Pecas_Criativas.Status_aprov%TYPE,
    p_justificativa IN VARCHAR2 DEFAULT NULL
)
IS
    v_status_atual VARCHAR2(20);
BEGIN
    -- Verificar se peça existe
    SELECT Status_aprov INTO v_status_atual
    FROM Pecas_Criativas
    WHERE Id_unicoPeca = p_id_peca;

    -- Atualizar status
    UPDATE Pecas_Criativas
    SET Status_aprov = p_novo_status
    WHERE Id_unicoPeca = p_id_peca;

    -- Registrar no log (se tivéssemos tabela de log)
    -- INSERT INTO Log_Aprovacao_Pecas ...

    COMMIT;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20003, 'Peça criativa não encontrada: ' || p_id_peca);
END sp_aprovar_rejeitar_peca;
/

