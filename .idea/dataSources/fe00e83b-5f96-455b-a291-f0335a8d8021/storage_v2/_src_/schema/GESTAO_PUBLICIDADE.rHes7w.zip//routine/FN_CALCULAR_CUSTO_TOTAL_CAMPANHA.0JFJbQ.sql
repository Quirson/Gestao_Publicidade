create FUNCTION fn_calcular_custo_total_campanha (
    p_cod_camp IN Campanha_Dados.Cod_camp%TYPE
) RETURN NUMBER
IS
    v_custo_base NUMBER := 0;
    v_desconto NUMBER := 0;
    v_cod_pagamento NUMBER;
    v_cod_promocao NUMBER;
BEGIN
    -- Buscar custo base dos espaços
    SELECT SUM(e.Preco_base)
    INTO v_custo_base
    FROM Campanha_Espaco ce
    JOIN Espaco_Dados e ON ce.Id_espaco = e.Id_espaco
    WHERE ce.Cod_camp = p_cod_camp;

    -- Buscar desconto da promoção
    BEGIN
        SELECT cd.Cod_pagamento, p.Cod_promocao
        INTO v_cod_pagamento, v_cod_promocao
        FROM Campanha_Dados cd
        LEFT JOIN Pagamentos p ON cd.Cod_pagamento = p.Cod_pagamento
        WHERE cd.Cod_camp = p_cod_camp;

        IF v_cod_promocao IS NOT NULL THEN
            SELECT Desc_volume INTO v_desconto
            FROM Promocoes
            WHERE Cod_promocao = v_cod_promocao;
        END IF;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            v_desconto := 0;
    END;

    -- Aplicar desconto
    RETURN NVL(v_custo_base, 0) * (1 - NVL(v_desconto, 0) / 100);

EXCEPTION
    WHEN OTHERS THEN
        RETURN 0;
END fn_calcular_custo_total_campanha;
/

