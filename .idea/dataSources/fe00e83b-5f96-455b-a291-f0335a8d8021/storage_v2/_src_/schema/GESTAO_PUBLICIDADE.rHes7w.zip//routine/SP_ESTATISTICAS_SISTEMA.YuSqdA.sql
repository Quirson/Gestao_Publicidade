create PROCEDURE sp_estatisticas_sistema (
    p_cursor OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN p_cursor FOR
    WITH stats AS (
        SELECT
            (SELECT COUNT(*) FROM Anunciante_Dados) as total_anunciantes,
            (SELECT COUNT(*) FROM Campanha_Dados) as total_campanhas,
            (SELECT COUNT(*) FROM Campanha_Dados WHERE Data_termino >= SYSDATE) as campanhas_ativas,
            (SELECT COUNT(*) FROM Espaco_Dados) as total_espacos,
            (SELECT COUNT(*) FROM Espaco_Dados WHERE Disponibilidade = 'Disponível') as espacos_disponiveis,
            (SELECT SUM(Orc_alocado) FROM Campanha_Dados WHERE Data_termino >= SYSDATE) as orcamento_total_ativas
        FROM DUAL
    )
    SELECT * FROM stats;
END sp_estatisticas_sistema;
/

